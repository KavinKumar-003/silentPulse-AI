# SilentPulse AI

A webcam-based non-contact heart rate monitor using remote photoplethysmography
(rPPG), with an experimental "pulse plausibility" check that can help flag
static photos or flat screen replays.

## What this actually does (read before demoing)

- **Heart rate estimate (BPM):** Real technique. Tracks tiny green-channel
  brightness changes on your forehead caused by blood flow, then isolates the
  heartbeat frequency with a bandpass filter + FFT. Works reasonably well in
  good, even lighting, with the subject relatively still.
- **Pulse plausibility check:** Looks at whether the extracted signal has the
  right frequency range, amplitude, and signal-to-noise ratio for a real
  pulse, and whether the face was stable enough to trust the reading.

## What this is **not**

- **Not a certified anti-spoofing or anti-deepfake system.** It's one useful
  signal among several a real system would need (document check, standard
  face match, additional liveness challenges, etc.). A good enough replay
  attack (e.g. a video that itself contains a real recorded pulse) could
  still pass.
- **Not a medical device.** Don't use the BPM reading for clinical decisions.
- **Not robust to poor conditions.** Bad lighting, heavy compression, dark
  skin under low light (contrast matters more than tone, but very low light
  hurts everyone), motion, and low-quality webcams will all degrade or break
  the reading — this is a known, real limitation of rPPG generally, not
  something this implementation "fixes."

## Setup

**Use a virtual environment.** Installing straight into your global Python
(as opposed to a project-specific venv) is the #1 cause of the dependency
conflicts people hit with this stack — `mediapipe` needs `numpy<2`, and if
you have other projects (FastAPI, scikit-learn, etc.) sharing your global
site-packages, installing this will fight with them and can silently break
both projects.

**Windows (PowerShell):**
```powershell
cd SilentPulse-AI
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run frontend/app_ui.py
```

**Mac/Linux:**
```bash
cd SilentPulse-AI
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
streamlit run frontend/app_ui.py
```

You'll know it worked if your terminal prompt shows `(venv)` at the start
of the line before you run `pip install`. Opens at `http://localhost:8501`.
Grant the browser/OS camera permission when prompted.

If you've already `pip install`-ed this into your global Python and want to
clean it up, the safest move is: create the venv above, then in your global
environment run `pip uninstall mediapipe opencv-python streamlit numpy
scipy plotly gTTS` and let `pip check` confirm your other projects
(FastAPI, scikit-learn) are back to their expected versions.

## Project structure

```
SilentPulse-AI/
├── backend/
│   ├── rppg_engine.py       # face ROI detection + signal extraction + FFT
│   ├── liveness_engine.py   # pulse plausibility scoring (honest framing)
│   └── voice_engine.py      # optional spoken status (needs internet; degrades gracefully offline)
├── frontend/
│   └── app_ui.py            # Streamlit dashboard
├── data/                    # session logs / voice mp3s written here at runtime
└── requirements.txt
```

## Troubleshooting

- **"Could not open webcam"** — close other apps using the camera (Zoom,
  Teams, browser tabs), check OS camera privacy settings, and try changing
  `cv2.VideoCapture(0)` to `1` in `app_ui.py` if you have multiple cameras.
- **BPM stuck at 0 / "Analyzing…" forever** — needs ~3-5 seconds of face
  detection in frame before it has enough data; make sure your whole face
  (especially forehead) is visible and well lit.
- **Voice alerts don't play** — `gTTS` requires an internet connection. The
  app will keep working without it; voice is optional.
- **`mediapipe` install issues** — mediapipe wheels are picky about Python
  version; Python 3.9–3.11 (64-bit) is the safest bet.

## Extending it

- Swap the green-channel-only extraction for the CHROM or POS algorithm for
  better robustness against lighting changes.
- Add multi-ROI averaging (forehead + both cheeks) to reduce noise.
- Log SNR-over-time to a rolling chart so users can see signal quality drift.
- If pursuing the identity-fraud-prevention angle further, pair this with an
  actual anti-spoofing model (e.g. a small CNN trained on print/replay attack
  datasets like CASIA-FASD or OULU-NPU) rather than relying on rPPG alone.
