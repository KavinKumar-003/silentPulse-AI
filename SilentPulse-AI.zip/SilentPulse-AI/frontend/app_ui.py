import streamlit as st
import cv2
import plotly.graph_objects as go
import time
import sys
import os
import csv
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.rppg_engine import RPPGEngine
from backend.liveness_engine import PulsePlausibilityEngine
from backend.voice_engine import VoiceEngine

st.set_page_config(page_title="SilentPulse AI", layout="wide", page_icon="💓")

st.title("💓 SilentPulse AI")
st.caption("Non-Contact Heart Rate & Pulse-Signal Plausibility Check (webcam-based rPPG)")

st.warning(
    "**What this actually does:** SilentPulse AI measures a real optical pulse "
    "signal (rPPG) from your webcam and checks whether it looks physiologically "
    "plausible. It is **one useful signal**, not a certified anti-spoofing or "
    "fraud-detection system — a sufficiently good video replay could still pass "
    "it, and low light or camera quality can produce false negatives. Combine it "
    "with other checks (document ID, standard face match, liveness challenge) "
    "in any real deployment.",
    icon="⚠️",
)

st.markdown("---")

col1, col2 = st.columns([2, 1])

if "rppg" not in st.session_state:
    st.session_state.rppg = RPPGEngine()
if "log" not in st.session_state:
    st.session_state.log = []

rppg = st.session_state.rppg

with st.sidebar:
    st.header("Settings")
    voice_enabled = st.checkbox("Voice alerts (needs internet)", value=False)
    lang = st.selectbox(
        "Voice language",
        options=["hi", "en", "ta", "te"],
        format_func=lambda x: {"hi": "Hindi", "en": "English", "ta": "Tamil", "te": "Telugu"}[x],
    )
    st.markdown("---")
    if st.button("Reset signal buffer"):
        rppg.reset()
        st.session_state.log = []
        st.rerun()

    st.markdown("---")
    st.subheader("Session Log")
    if st.session_state.log:
        st.dataframe(st.session_state.log[-10:], use_container_width=True)
        csv_path = "data/session_log.csv"
        os.makedirs("data", exist_ok=True)
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=st.session_state.log[0].keys())
            writer.writeheader()
            writer.writerows(st.session_state.log)
        with open(csv_path, "rb") as f:
            st.download_button("Download log (CSV)", f, file_name="silentpulse_session_log.csv")
    else:
        st.caption("No readings yet.")

with col1:
    st.subheader("📹 Live Camera Feed")
    run_cam = st.checkbox("Start Live Camera", value=False)
    FRAME_WINDOW = st.image([])

with col2:
    st.subheader("📊 Biometric Metrics")
    bpm_metric = st.empty()
    quality_metric = st.empty()
    liveness_metric = st.empty()
    explanation_box = st.empty()
    st.markdown("---")
    st.subheader("📈 Real-Time Blood Pulse Waveform")
    chart_placeholder = st.empty()
    audio_placeholder = st.empty()

if run_cam:
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        st.error("Could not open webcam. Check that no other app is using the camera and that "
                 "browser/OS camera permissions are granted.")
    else:
        last_voice_status = None
        try:
            while run_cam:
                ret, frame = cap.read()
                if not ret:
                    st.error("Lost connection to webcam.")
                    break

                frame = cv2.flip(frame, 1)
                bpm, filtered_signal, meta = rppg.process_frame(frame)

                if isinstance(meta, dict) and meta.get("bbox"):
                    x, y, w, h = meta["bbox"]
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.putText(frame, "Forehead ROI", (x, y - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                elif meta == "NO_FACE":
                    cv2.putText(frame, "No face detected", (20, 40),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

                FRAME_WINDOW.image(frame, channels="BGR")

                if bpm > 0 and isinstance(meta, dict):
                    motion = meta.get("motion", 0.0)
                    snr = meta.get("snr", 0.0)

                    bpm_metric.metric(label="Heart Rate (BPM)", value=f"{bpm} BPM")
                    quality_metric.metric(label="Signal Quality (SNR)", value=f"{snr:.2f}")

                    status, confidence, color, explanation = PulsePlausibilityEngine.evaluate(
                        filtered_signal, bpm, motion=motion, snr=snr
                    )

                    if color == "green":
                        liveness_metric.success(f"**{status}** — confidence {confidence}%")
                    elif color == "red":
                        liveness_metric.error(f"**{status}** — confidence {confidence}%")
                    else:
                        liveness_metric.info(f"**{status}**")

                    explanation_box.caption(explanation)

                    if status in (PulsePlausibilityEngine.STATUS_PULSE_FOUND,
                                  PulsePlausibilityEngine.STATUS_NO_PULSE):
                        st.session_state.log.append({
                            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "bpm": bpm,
                            "status": status,
                            "confidence": confidence,
                            "snr": round(snr, 2),
                        })
                        if voice_enabled and status != last_voice_status:
                            audio_file = VoiceEngine.speak_result(bpm, status, lang=lang)
                            if audio_file:
                                audio_placeholder.audio(audio_file)
                            last_voice_status = status

                    if filtered_signal:
                        fig = go.Figure()
                        fig.add_trace(go.Scatter(
                            y=filtered_signal[-90:], mode="lines",
                            line=dict(color="#EC4899", width=2)
                        ))
                        fig.update_layout(
                            height=220, margin=dict(l=10, r=10, t=10, b=10),
                            yaxis=dict(visible=False),
                        )
                        chart_placeholder.plotly_chart(fig, use_container_width=True)
                else:
                    bpm_metric.metric(label="Heart Rate (BPM)", value="Analyzing…")
                    quality_metric.metric(label="Signal Quality (SNR)", value="—")
                    liveness_metric.info("Keep your face centered, well-lit, and hold still for ~5 seconds.")
                    explanation_box.empty()

                time.sleep(0.03)
        finally:
            cap.release()
