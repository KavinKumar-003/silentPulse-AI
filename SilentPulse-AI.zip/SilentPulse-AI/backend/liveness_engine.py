"""
liveness_engine.py

IMPORTANT — HONEST FRAMING:
This module does NOT prove someone is "real" or catch every deepfake.
It checks one thing: does the video contain a plausible, physiological
pulse signal (right amplitude, right frequency range, decent signal-to-
noise ratio, and a face that isn't jittering wildly)?

A static photo or a flat screen replay usually has NO such signal, so this
is a genuinely useful *one* signal to combine with other checks (document
verification, standard face-match, etc.) in a real system. It is not, by
itself, a certified anti-spoofing or anti-deepfake system, and a
sufficiently sophisticated attack (e.g. a video replay that itself
contains a real recorded pulse) could pass it. Treat the output as
"pulse signal plausible / not found", never as a fraud verdict on its own.
"""

import numpy as np


class PulsePlausibilityEngine:
    STATUS_ANALYZING = "ANALYZING"
    STATUS_PULSE_FOUND = "PULSE SIGNAL DETECTED"
    STATUS_NO_PULSE = "NO PULSE SIGNAL FOUND"
    STATUS_LOW_QUALITY = "LOW SIGNAL QUALITY — CHECK LIGHTING / HOLD STILL"

    @staticmethod
    def evaluate(filtered_signal, bpm, motion=0.0, snr=0.0):
        """
        Returns (status_text, confidence_0_to_100, color, explanation)

        This function makes a *plausibility* judgment, not a fraud verdict.
        """
        if len(filtered_signal) < 60 or bpm == 0:
            return (
                PulsePlausibilityEngine.STATUS_ANALYZING,
                0.0,
                "yellow",
                "Collecting enough frames to analyze the signal (~3-5 seconds needed).",
            )

        # Too much face movement corrupts the rPPG signal — this is a real,
        # known limitation, not something we can silently work around.
        if motion > 25:
            return (
                PulsePlausibilityEngine.STATUS_LOW_QUALITY,
                0.0,
                "yellow",
                "Face is moving too much for a reliable reading. Hold still and ensure even lighting.",
            )

        peak_to_peak = float(np.ptp(filtered_signal))
        signal_std = float(np.std(filtered_signal))

        physiological_range_ok = 45 <= bpm <= 180
        amplitude_ok = 0.08 <= peak_to_peak <= 8.0
        snr_ok = snr >= 1.5  # peak must clearly stand out above the noise floor

        if physiological_range_ok and amplitude_ok and snr_ok:
            # Confidence scales with SNR, capped conservatively — we never
            # claim certainty.
            confidence = min(92.0, 55.0 + snr * 8.0 + signal_std * 3.0)
            return (
                PulsePlausibilityEngine.STATUS_PULSE_FOUND,
                round(confidence, 1),
                "green",
                "A physiologically plausible pulse waveform was detected in the video "
                "(right frequency range, consistent amplitude, clear signal above noise).",
            )
        else:
            return (
                PulsePlausibilityEngine.STATUS_NO_PULSE,
                round(max(5.0, 30.0 - snr * 5.0), 1),
                "red",
                "No plausible pulse waveform found. This can mean a static image, a screen "
                "replay, poor lighting/camera quality, or the subject was moving — it is "
                "not a definitive fraud determination on its own.",
            )
