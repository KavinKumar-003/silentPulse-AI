"""
voice_engine.py

Generates a short spoken status update (Hindi by default) using gTTS
(needs internet). If gTTS/network is unavailable, this fails gracefully
instead of crashing the app — voice is a nice-to-have, not a dependency
the core rPPG/pulse-check pipeline should rely on.
"""

import os


class VoiceEngine:
    @staticmethod
    def speak_result(bpm, status_text, lang="hi"):
        """
        status_text should be one of PulsePlausibilityEngine's STATUS_* values.
        Returns the path to the generated mp3, or None if generation failed
        (e.g. no internet) — callers should handle None without erroring.
        """
        try:
            from gtts import gTTS
        except ImportError:
            return None

        if status_text == "PULSE SIGNAL DETECTED":
            text = f"पल्स सिग्नल मिला। हृदय गति लगभग {bpm} बीट्स प्रति मिनट है।"
        elif status_text == "NO PULSE SIGNAL FOUND":
            text = "कोई स्पष्ट पल्स सिग्नल नहीं मिला। कृपया रोशनी जांचें या दोबारा प्रयास करें।"
        else:
            text = "विश्लेषण जारी है, कृपया प्रतीक्षा करें।"

        try:
            os.makedirs("data", exist_ok=True)
            output_file = os.path.join("data", "voice_alert.mp3")
            tts = gTTS(text=text, lang=lang, slow=False)
            tts.save(output_file)
            return output_file
        except Exception:
            # No internet, quota issue, etc. — degrade silently.
            return None
