"""
rppg_engine.py

Extracts a remote-photoplethysmography (rPPG) signal from a webcam feed by
tracking subtle green-channel brightness changes on the forehead, caused by
blood volume changes under the skin with each heartbeat.

This is a real, well-established technique (see: Verkruysse et al. 2008,
"Remote plethysmographic imaging using ambient light"). It is NOT a medical
device and should not be used for clinical decisions.
"""

import cv2
import numpy as np
from collections import deque
from scipy.signal import butter, filtfilt
import mediapipe as mp


class RPPGEngine:
    def __init__(self, buffer_size=150, fps=30):
        """
        buffer_size: number of frames kept in the rolling window (150 @ 30fps = 5s)
        fps: expected camera frame rate, used to tune the bandpass filter
        """
        self.buffer_size = buffer_size
        self.fps = fps
        self.green_means = deque(maxlen=buffer_size)
        self.bbox_history = deque(maxlen=15)  # used for motion-artifact detection

        self.mp_face_detection = mp.solutions.face_detection
        self.face_detection = self.mp_face_detection.FaceDetection(
            model_selection=0, min_detection_confidence=0.6
        )

    def extract_forehead_roi(self, frame):
        """Detects a face and returns the forehead ROI + its bounding box."""
        h, w, _ = frame.shape
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_detection.process(rgb_frame)

        if not results.detections:
            return None, None

        # Use the largest/most confident detection if multiple faces are present
        detection = max(
            results.detections,
            key=lambda d: d.location_data.relative_bounding_box.width
            * d.location_data.relative_bounding_box.height,
        )

        bboxC = detection.location_data.relative_bounding_box
        xmin = max(0, int(bboxC.xmin * w))
        ymin = max(0, int(bboxC.ymin * h))
        box_w = int(bboxC.width * w)
        box_h = int(bboxC.height * h)

        # Forehead sub-region (avoids eyebrows/hairline/glasses)
        fh_xmin = max(0, xmin + int(box_w * 0.25))
        fh_ymin = max(0, ymin + int(box_h * 0.08))
        fh_w = max(1, int(box_w * 0.50))
        fh_h = max(1, int(box_h * 0.18))

        roi = frame[fh_ymin:fh_ymin + fh_h, fh_xmin:fh_xmin + fh_w]
        if roi.size == 0:
            return None, None

        return roi, (xmin, ymin, box_w, box_h)

    def _motion_score(self, bbox):
        """Rough measure of how much the face bbox has jittered recently.
        Large motion degrades rPPG signal quality (this is a known real
        limitation of the technique, not something we can filter away)."""
        self.bbox_history.append(bbox)
        if len(self.bbox_history) < 2:
            return 0.0
        diffs = []
        prev = self.bbox_history[0]
        for cur in list(self.bbox_history)[1:]:
            diffs.append(abs(cur[0] - prev[0]) + abs(cur[1] - prev[1]))
            prev = cur
        return float(np.mean(diffs))

    def process_frame(self, frame):
        """Feed one BGR frame in. Returns (bpm, filtered_signal, bbox_or_status)."""
        roi, bbox = self.extract_forehead_roi(frame)
        if roi is None:
            return 0, [], "NO_FACE"

        green_mean = float(np.mean(roi[:, :, 1]))
        self.green_means.append(green_mean)

        motion = self._motion_score(bbox)

        bpm = 0
        filtered_signal = []
        snr = 0.0

        if len(self.green_means) >= 90:  # need ~3s of data before trusting FFT
            bpm, filtered_signal, snr = self.calculate_bpm()

        return bpm, filtered_signal, {"bbox": bbox, "motion": motion, "snr": snr}

    def calculate_bpm(self):
        signal = np.array(self.green_means, dtype=np.float64)
        signal = signal - np.mean(signal)

        lowcut, highcut = 0.75, 3.0  # 45-180 BPM
        nyq = 0.5 * self.fps
        b, a = butter(2, [lowcut / nyq, highcut / nyq], btype="band")
        filtered = filtfilt(b, a, signal)

        fft_data = np.abs(np.fft.rfft(filtered))
        freqs = np.fft.rfftfreq(len(filtered), 1.0 / self.fps)

        valid_idx = np.where((freqs >= lowcut) & (freqs <= highcut))
        valid_fft = fft_data[valid_idx]
        valid_freqs = freqs[valid_idx]

        if len(valid_fft) == 0:
            return 0, filtered.tolist(), 0.0

        peak_idx = int(np.argmax(valid_fft))
        peak_power = valid_fft[peak_idx]
        peak_freq = valid_freqs[peak_idx]
        bpm = peak_freq * 60.0

        # Signal-to-noise ratio: peak power vs. average of the rest of the band.
        # This is a genuine, useful confidence proxy — a flat/noisy spectrum
        # (typical of a static photo or bad lighting) has a low SNR.
        other_power = np.delete(valid_fft, peak_idx)
        noise_floor = np.mean(other_power) if len(other_power) > 0 else 1e-6
        snr = float(peak_power / (noise_floor + 1e-6))

        return int(np.round(bpm)), filtered.tolist(), snr

    def reset(self):
        self.green_means.clear()
        self.bbox_history.clear()
